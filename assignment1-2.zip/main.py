#intro
import random
num_one=random.randint(0,5)
num_two=random.randint(0,5)
true_answer=num_one*num_two
name=input("what is your name?\n")
print("Hello",name,"what grade are you in?")
print("1. Grade 1-2")
print("2. Grade 3-4")
print("3. Grade 5-6")
grade=int(input(""))
num_one=random.randint(0,5)
num_two=random.randint(0,5)
true_answer=num_one*num_two
#grade1
if(grade==1):
 print("What is",num_one,"x",num_two,"?")
 answer=int(input(""))
 print("you have answered",answer,)
if (answer==true_answer):
 print("You are correct")
else:
  print("you are incorrect")

  #grade2
num_one=random.randint(0,10)
num_two=random.randint(0,10)
true_answer=num_one
if(grade==2):
   print("What is",num_one,
"X",num_two,"?")
answer=int(input(""))
if (answer==true_answer):
   print("You are correct")
if (answer!=true_answer):
   print("you are incorrect")

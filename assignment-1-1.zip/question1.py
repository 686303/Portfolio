print("how many pizzas would you like to purchase?")
pizza = float(input(""))
cost_slice = 2
cost_box = 20
cost_bundle = 140
number_of_box = int(pizza) / 12
number_of_box = "{:.0f}".format(number_of_box)
remaining_slice = pizza % 12
remaining_slice = "{:.0f}".format(remaining_slice)
number_of_bundles = float(number_of_box) / 8
number_of_bundles = "{:.0f}".format(number_of_bundles)
remaining_box = float(number_of_box) % 8
total_box_cost = float(cost_box) * float(number_of_box)
total_box_remainder_cost = float(cost_box * remaining_box)
total_bundle_cost = float(cost_bundle) * float(number_of_bundles)
total_slice_cost = cost_slice * pizza
remaning_slice_cost = float(remaining_slice) * float(cost_slice)
#variables
if (pizza <= 140):
    print("The number of bundles needed:0\n"
          "the number of boxes needed:", number_of_box,
          "\nnumber of single slices needed:", remaining_slice, "\n"
          "the cost of your order is:", total_box_cost + remaning_slice_cost,
          "$")
else:
    print("The number of bundles needed:", number_of_bundles,
          "\nThe number of boxes needed:", remaining_box,
          "\nThe number of slices needed:", remaining_slice,
          "\nThe cost of your order is: $",
          total_bundle_cost + total_box_remainder_cost + remaning_slice_cost,
          )

#functions ex1
def shut_down(command):
     if command == "yes":
        print("Shutting down...")
     elif command == "no":
        print("Shutdown Aborted!")
     else:
       return("Sorry,command not recognized")

outcome=shut_down("YAES")


#example 2
def rec_perimeter(length, width):
  perimeter =2*length +2*width
  return perimeter

print("The perimeter of your rectngle is",rec_perimeter(3,4))
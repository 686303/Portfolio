passing_grade=50
student_grade=int(input(""))

if student_grade>passing_grade:
  student_pass=True
elif student_grade < passing_grade:
  student_pass=False
elif student_grade == 50:
  print("you passed (barely)")

if student_pass:
 print("you passed")
elif student_grade == passing_grade:
  print("you passed (barely)")
else:
  print("you failed")
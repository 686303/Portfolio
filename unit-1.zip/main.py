name = input("what is your name?")
grade = input("what grade are you in?")
subject = input("Whats your favorite subject")
print("Hello", name, "In grade", grade, "my favorite subject is", subject,
      "as well!")
print(":)")

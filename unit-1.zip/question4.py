length=float(input("what is the length if the rectangle\n"))
width=float(input("what is the width of the rectangle\n"))
area=length*width
perimeter=2*(length+width)
print("The area of the rectangle is",area,"while the perimeter is",perimeter)
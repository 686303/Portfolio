name=input("what is your name?\n")
number=int(input("What is your favorite number"))
remainder= number % 2
if(remainder==0):
  print("your number is even")
else:
    print("your number is odd")

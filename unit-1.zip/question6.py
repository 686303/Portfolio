radius=float(input("Input the radius of the circle\n"))
area=radius*radius*3.14159
area = "{:.2f}".format(area)
print("The area is",area,)
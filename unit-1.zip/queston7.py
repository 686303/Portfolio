print("Hello,what would you like to see?\n 1.Display today's temperature\n 2.Display my current location\n 3. Display an activity recommendation\n 4.Display all information")
num=int(input(""))
temp=15
if (num==1):
  print("It is",temp,"degrees")
elif(num==2):
  print("You are in Ontario")
elif(num==3):
  print("How about a bike ride?")
elif(num==4):
    print("Hello friend! It is",temp,"degrees in Brampton, great day for a bike ride")
  
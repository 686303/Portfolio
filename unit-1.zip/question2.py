
num_one=input("Input 1st number/n")
num_two=input("Input 2nd number")
the_product= num_one * num_two
print("the product is",the_product,)

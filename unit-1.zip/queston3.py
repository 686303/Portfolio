num_one=int(input("insert 1st number"))
num_two=int(input("insert 1st number"))
quotient= num_one / num_two
print("the quotient is:",int(quotient))
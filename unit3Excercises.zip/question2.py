integer=int(input("please input a random number you think can be divided by 3: "))
remainder=integer%3
if remainder==0:
  integer=True
else:
  integer=False

if integer:
  print("Yes it can be divided by 3")
else:
  print("no it cannot be divided by 3")
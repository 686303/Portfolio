#part A
ten=10
while ten==10: 
  print("bruh")

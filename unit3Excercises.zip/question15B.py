ten=10
loop=0
while ten==10: 
  print("bruh")
  loop=loop+1
  if loop==2020:
    break
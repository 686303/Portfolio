string=input("Please enter your string: ")
remainder=len(string)%2
first_half, second_half=string[:len(string)//2],string[len(string)//2:]
first_halfer, second_halfer=string[:len(string)//2] ,string[:len(string)//2:]
if remainder==0:
  print("The first half of the word is ",first_half,)
  print("The second half of the word is ",second_half,)
else:
  print("The first half of the word is",first_half,)
  print("The second half of the word is",second_half,)
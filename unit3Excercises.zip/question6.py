number=int(input("Enter your favorite number"))
for num in range(1,number+1):
 print(num)
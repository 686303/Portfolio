integer=int(input("Please enter a positive integer: "))
while integer > 0:
  print(integer)
  integer=integer-1
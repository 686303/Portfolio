string=(input("Please enter a string: "))
if len(string)>=3:
 print(string[-3:])
else:
  print("The string you entered is too short.")
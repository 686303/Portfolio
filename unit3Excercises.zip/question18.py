number=int(input("Enter your number: "))
num=number
remainder=number%2
count=0
while number > 1:
  number=number//2
  count=count+1
  print(number)
if number==1:
  print(num,"contains atleast",count,"exponents of 2" )
  

word=input("Input a word: ")
print(len(word))
levels=int(input("Please enter the number of levels you'd like: "))
number=""
#---
for i in range(levels):
  square=number**2
  print(square + square)+square

print(square)
global total
number=int(input("Enter your favorite number: "))
total=0
for number in range(number-1, 10):
  diget=number+1
  total=total+diget
  print(total)

print(total)

string = 'The quick brown fox jusmps over the lazy dog'
# Define your variables
result = ''
for i in string:
        if i == 'q':
                i = '0'
        result += i
print (result)
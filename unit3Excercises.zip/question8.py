import random
num_one=random.randint(0,5)
num_two=random.randint(0,5)
true_answer=num_one*num_two
correct=0
name=input("what is your name?\n")
print("Hello",name,"we will play a multiplication game of 5 questions")
num_one=random.randint(0,5)
num_two=random.randint(0,5)
true_answer=num_one*num_two
#grade1
for x in range(5):
 num_one=random.randint(0,5)
 num_two=random.randint(0,5)
 true_answer=num_one*num_two
 print("What is",num_one,"x",num_two,"?")
 answer=int(input(""))
 if answer==true_answer:
  print("you have answered",answer, "You are correct")
  correct=correct+1
 else:
   print("you have answered",answer,"You are incorrect")
    
print("you got",correct,"correct")
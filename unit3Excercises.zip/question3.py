question1=input("Are you having a good day? yes or no?: ")
question2=input("Are you smiling? yes or no?: ")

if question1=="yes":
  question1=True
else:
  question1=False

if question2=="yes":
  question2=True
else:
  question2=False

if question1==True and question2==True:
  print("Nice to smile on a good day!")
elif question1==True and question2==False:
  print("Be happy & smile!")
elif question1==False and question2==True:
  print("Be happy & smile")
else:
  print("Go for a walk, It'll make you feel better")
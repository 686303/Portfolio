import time
seconds=int(input("Please enter the Seconds you'd like to count down: "))
for i in range(seconds, 0,-1):
  print("Counting down",i,"second(s) left...")
  time.sleep(1)

print("DING DING DING! Time is up")
Temperature=int(input("What is the temperature?: "))
Season=int(input("What is the season? \n 1.spring \n 2.summer\n 3.fall\n 4.winter\n"))

if Temperature >=20 and Temperature <=30 and Season==1 or Season==3 or Season==4:
  print("The squirrels are playing!")
elif Season==2 and Temperature <=40 and Temperature >=20:
  print("The squirrels are playing!")
else:
  print("Not sutible weather for squirrel play")
var_one=10>1
var_two=10<1

print(var_one, var_two)
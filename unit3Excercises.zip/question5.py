sentence=input("Enter a sentence: \n")
keyword=input("Enter a keyword: \n")
#space
if keyword in sentence:
  print("yes",keyword,"is in the sentence")
else:
  print("no",keyword,"is not in the sentence")
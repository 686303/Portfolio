string=input("Please enter a string: ")
start=string[:]
end=string[::-1]

if start==end:
  print("The string is a palindrome")
else:
  print("The string is not a palindrome")

print(start)
print(end)
